
module pwm_generator(
    input clk_3125KHz,
    input [3:0] duty_cycle,
    output reg clk_195KHz, pwm_signal
);

initial begin
    clk_195KHz = 0; pwm_signal = 1;
end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////
reg [2:0] counter_clk = 0;
reg [3:0] counter_pwm = 0;

always @(posedge clk_3125KHz) begin
if(!counter_clk) clk_195KHz = ~clk_195KHz;
counter_clk = counter_clk +1;
end

always @ (posedge clk_3125KHz) begin

if (counter_pwm == 4'd15) begin
counter_pwm <= 0;
end else begin
counter_pwm <= counter_pwm + 1;
end
if (counter_pwm < duty_cycle) begin
pwm_signal <= 1;
end else begin 
pwm_signal <= 0;
end

end 
//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule
