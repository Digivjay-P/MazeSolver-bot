// data_mem.v - data memory

module data_mem #(parameter DATA_WIDTH = 32, ADDR_WIDTH = 32, MEM_SIZE = 64) (
    input       clk, wr_en,
    input       [ADDR_WIDTH-1:0] wr_addr, wr_data,
    input       [2:0] load_type,   // from controller: 000 LB,001 LH,010 LW,100 LBU,101 LHU
    input       [1:0] store_type,  // from controller: 00 SB,01 SH,10 SW
    output      [DATA_WIDTH-1:0] rd_data_mem
);

  // 32-bit words in memory
  reg [DATA_WIDTH-1:0] data_ram [0:MEM_SIZE-1];

  // derive index width and slice address correctly
 localparam IDXW = (MEM_SIZE <= 1) ? 1 : $clog2(MEM_SIZE);
  wire [IDXW-1:0] widx = wr_addr[2 + IDXW - 1 : 2]; // word index within MEM_SIZE
  wire [1:0]      off  = wr_addr[1:0];              // byte offset within the word

  // read the full word combinationally
  wire [31:0] word_r = data_ram[widx];

  // select byte / halfword based on offset
  wire [7:0]  sel_byte = (off == 2'd0) ? word_r[7:0]   :
                         (off == 2'd1) ? word_r[15:8]  :
                         (off == 2'd2) ? word_r[23:16] : word_r[31:24];

  wire [15:0] sel_half = (off[1] == 1'b0) ? word_r[15:0] : word_r[31:16];

  // sign/zero-extended read data
  wire [DATA_WIDTH-1:0] rd_mux =
      (load_type == 3'b000) ? {{24{sel_byte[7]}},  sel_byte} :   // LB
      (load_type == 3'b001) ? {{16{sel_half[15]}}, sel_half} :     // LH
      (load_type == 3'b010) ? word_r: // LW
      (load_type == 3'b100) ? {24'b0, sel_byte}  : // LBU
      (load_type == 3'b101) ? {16'b0, sel_half}  : // LHU
                              {DATA_WIDTH{1'b0}};

  assign rd_data_mem = rd_mux;

  // masked writes for SB/SH/SW
  always @(posedge clk) begin
    if (wr_en) begin
      case (store_type)
        2'b00: begin // SB
          case (off)
            2'd0: data_ram[widx][7:0]    <= wr_data[7:0];
            2'd1: data_ram[widx][15:8]   <= wr_data[7:0];
            2'd2: data_ram[widx][23:16]  <= wr_data[7:0];
            2'd3: data_ram[widx][31:24]  <= wr_data[7:0];
          endcase
        end
        2'b01: begin // SH (natural alignment by off[1])
          if (off[1] == 1'b0)
            data_ram[widx][15:0]  <= wr_data[15:0];
          else
            data_ram[widx][31:16] <= wr_data[15:0];
        end
        2'b10: begin // SW
          data_ram[widx] <= wr_data;
        end
        default: ; // no write
      endcase
    end
  end

endmodule
