
// riscv_cpu.v - single-cycle RISC-V CPU Processor

module riscv_cpu (
    input         clk, reset,
    output [31:0] PC,
    input  [31:0] Instr,
    output        MemWrite,
    output [31:0] Mem_WrAddr, Mem_WrData,
    input  [31:0] ReadData,
    output [31:0] Result,
	 output [2:0] load_type,
	 output [1:0] store_type
);

wire        ALUSrc, RegWrite, Jump, Zero, PCSrc;
wire [1:0]  ResultSrc;
wire [2:0]  ImmSrc;
wire [3:0]  ALUControl; 
wire UsePC, lt, ltu;

//Instr [6:0] -- op code
//Instr [14:12] -- funct3
//Instr [30] -- funct7b5
controller  c   (Instr[6:0], Instr[14:12], Instr[30], Zero,lt, ltu,
                ResultSrc, MemWrite, PCSrc, ALUSrc, RegWrite, Jump,
                ImmSrc, ALUControl, load_type, store_type, UsePC);

datapath    dp  (clk, reset, ResultSrc, PCSrc,
                ALUSrc, RegWrite, ImmSrc, ALUControl,UsePC,
                Zero, PC, Instr, Mem_WrAddr, Mem_WrData, ReadData, Result, lt, ltu);
					 




endmodule

