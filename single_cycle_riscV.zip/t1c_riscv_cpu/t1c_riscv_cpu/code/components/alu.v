
// alu.v - ALU module
/*
0000 ADD
0001 SUB
0010 AND
0011 OR
0100 SLL,SLLI
0101 SLT,SLTI
0110 SLTU,SLTUI
0111 XOR,XORI
1000 SRA,SRAI
1001 SRL,SRLI 
*/

module alu #(parameter WIDTH = 32) (
    input       [WIDTH-1:0] a, b,       // operands
    input       [3:0] alu_ctrl,         // ALU control
    output reg  [WIDTH-1:0] alu_out,    // ALU output
    output      zero                    // zero flag
);

wire [4:0] shift_amt = b[4:0];



always @(*) begin
    case (alu_ctrl)
        4'b0000:  alu_out <= a + b;         // ADD
        4'b0001:  alu_out <= a + ~b + 1;    // SUB  (by 2s compliment method )
        4'b0010:  alu_out <= a & b;         // AND
        4'b0011:  alu_out <= a | b;         // OR         
		  4'b0100:  alu_out <= a << shift_amt; // SLL   //shift left logical
        4'b0101:  begin                     // SLT   //set less than signed 
                     if (a[31] != b[31]) alu_out <= a[31] ? 1 : 0;   //meaning MSB are unequal so if a[31] means it is negative then a is less than b thus output 1
                     else alu_out <= a < b ? 1 : 0;
                 end
		  4'b0110:  alu_out <= a < b ? 1 : 0; //SLTU   //set less than unsigned
		  4'b0111:  alu_out <= a ^ b;		     //XOR
		  4'b1000:  alu_out <= $signed(a) >>> shift_amt;  //SRA   (shift right arithmetic)
		  4'b1001:  alu_out <= a >> shift_amt;	  //SRL   (shift right logical )
        default: alu_out = 0;               //other cases out = 0 
    endcase
end

assign zero = (alu_out == 0) ? 1'b1 : 1'b0;   //zero flag is high when ALU output is 0

endmodule

