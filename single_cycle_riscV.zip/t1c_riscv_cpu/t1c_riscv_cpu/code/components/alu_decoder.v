
/*
alu_decoder.v - logic for ALU decoder
This module decides which specific ALU operation should be performed, based on the instruction’s funct3, funct7, 
and the high-level ALUOp signal coming from the main control unit \

The main decoder tells the type of ALU operation, ALU decoder figures out the exact operation 

output is 4 bit ALU control that goes to ALU unit
*/

module alu_decoder (
    input            opb5,
    input [2:0]      funct3,
    input            funct7b5,
    input [1:0]      ALUOp,
    output reg [3:0] ALUControl
);

always @(*) begin
    case (ALUOp)
	       // addition
        2'b00: ALUControl = 4'b0000; 
           
			 // subtraction
        2'b01: ALUControl = 4'b0001; 
		  
        default:
            case (funct3) // R-type or I-type ALU
				
                3'b000: begin   
                    // True for R-type subtract
                    if   (opb5 && funct7b5) ALUControl = 4'b0001; //sub   //func7 for 51 and func3=000 is 0100000 so func7b5 is 1 
                    else ALUControl = 4'b0000; // add (R), addi (I)
                end
					 
		/*1*/		 3'b001:  ALUControl = 4'b0100; // slli, sll, Control = 4
      /*2*/	    3'b010:  ALUControl = 4'b0101; // slt, slti Control = 5
		/*3*/	    3'b011:  ALUControl = 4'b0110; // sltui, sltu Control = 6
		/*4*/	    3'b100:  ALUControl = 4'b0111; //xori, xor
		/*5*/	    3'b101:  begin
		                   if(funct7b5) ALUControl = 4'b1000; //srai, sra  //8
								 else ALUControl = 4'b1001; // srli, srl  //9
	  	                   end
      /*6*/     3'b110:  ALUControl = 4'b0011; // or, ori, Control = 3 
      /*7*/     3'b111:  ALUControl = 4'b0010; // and, andi  Control = 2 
                default: ALUControl = 4'b0000; 
            endcase
    endcase
end

endmodule

