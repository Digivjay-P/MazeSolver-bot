
// adder.v - logic for adder

module adder #(parameter WIDTH = 32) (
    input       [WIDTH-1:0] a, b,   // operands
    output      [WIDTH-1:0] sum     // result (a+b)
);

assign sum = a + b;

endmodule

