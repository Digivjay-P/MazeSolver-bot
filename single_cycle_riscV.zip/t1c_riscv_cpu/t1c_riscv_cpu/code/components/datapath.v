
// datapath.v
module datapath (
    input         clk, reset,
    input [1:0]   ResultSrc,
    input         PCSrc, ALUSrc,
    input         RegWrite,
    input [2:0]   ImmSrc,
    input [3:0]   ALUControl,
	 input         UsePC,    //add for AUIPC instruction to create a simple mux that drive PC to a input of ALu
    output        Zero,  // 
    output [31:0] PC,
    input  [31:0] Instr,
    output [31:0] Mem_WrAddr, Mem_WrData,
    input  [31:0] ReadData,
    output [31:0] Result,   
	 output lt, ltu   //for branch instructions  ( lt-less than, ltu- less than unsigned )
);
 
wire [31:0] PCNext, PCPlus4, PCTarget;
wire [31:0] ImmExt, RegA, SrcA, SrcB, WriteData, ALUResult;

// next PC logic
reset_ff #(32) pcreg(clk, reset, PCNext, PC);
adder          pcadd4(PC, 32'd4, PCPlus4);


wire [31:0] JalrTarget, BranchTarget;  // Target address

wire [31:0] JalrSum;
assign JalrSum     = RegA + ImmExt;                // rs1 + imm
assign JalrTarget  = {JalrSum[31:1], 1'b0};        // force bit0 = 0
assign BranchTarget = PC + ImmExt;                 // PC + imm (JAL/branches)
assign PCTarget     = (Instr[6:0] == 7'b1100111) ? JalrTarget : BranchTarget;

mux2 #(32) pcmux(PCPlus4, PCTarget, PCSrc, PCNext);


// register file logic
reg_file       rf (clk, RegWrite, Instr[19:15], Instr[24:20], Instr[11:7], Result, RegA, WriteData);
imm_extend     ext (Instr[31:7], ImmSrc, ImmExt);

// ALU logic
mux2 #(32)     srca_mux(RegA, PC, UsePC, SrcA);           //for ALU a input (to choose between input being reg or PC ) (for AUIPC )
mux2 #(32)     srcbmux(WriteData, ImmExt, ALUSrc, SrcB);  //for ALU b input (to choose between imm and reg )
alu            alu (SrcA, SrcB, ALUControl, ALUResult, Zero);


//Comparator logic for branch

assign lt  = ($signed(SrcA) < $signed(SrcB));  // for BLT/BGE 
assign ltu = (SrcA < SrcB);               // for BLTU/BGEU 

mux3 #(32)     resultmux(ALUResult, ReadData, PCPlus4, ResultSrc, Result);

assign Mem_WrData = WriteData;
assign Mem_WrAddr = ALUResult;

endmodule

