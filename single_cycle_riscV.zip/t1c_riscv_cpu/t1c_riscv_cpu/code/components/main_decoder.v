
/*
 main_decoder.v - logic for main decoder
This Module takes the 7-bit opcode and 3 bit funct3 field from an instruction and generates
all the control signals required for the datapath components.
It basically tells the CPU what kind of instructions is being executed 

Control Signal is of the format -- RegWrite_ImmSrc_ALUSrc_MemWrite_ResultSrc_Branch_ALUOp_Jump_UsePC
*/

module main_decoder (
    input  [6:0] op,    //the op code from instruction
	 input  [2:0] funct3,  //3 bits funct3 used to refined the 
    output [1:0] ResultSrc,   // A multiplexer control telling the datapath what value should be written back into the register file
    output       MemWrite, //Control signal that enables writing to data memory (enable )
	 output       Branch,   //High for branch instruction otherwise low
	 output       ALUSrc,    //selects ALU input source (SRCB) (register vs immediate )
    output       RegWrite,   //enable writing into register files 
	 output       Jump,  //High for jump instructions otherwise low
    output [2:0] ImmSrc, // Selects how to interpret immediate bits from the instruction for the immediate generator
    output [1:0] ALUOp,  // fed into alu decoder
	 output [2:0] load_type,  // control signal to choose the type of load operation that needs to be performed (lb,lh, lw, lbu, lhu)
	 output [1:0] store_type, // control signal to choose the type of load operation that needs to be performed (sb,sh,sw)
	 output UsePC    //select ALU input source (SRCA) (PC or register) ( used in AUIPC instr)
);

reg [12:0] controls;   //13 bits for 9 control signals 
reg [2:0]  load_type_r;
reg [1:0]  store_type_r;

always @(*) begin
 
    // initialize all signals to zero to avoid latches
    controls      = 13'b0_000_0_0_00_0_00_0_0;
    load_type_r   = 3'b000;
    store_type_r  = 2'b00;
	 
    case (op)
        // RegWrite_ImmSrc_ALUSrc_MemWrite_ResultSrc_Branch_ALUOp_Jump_UsePC
		  
		    //Load Type -- 
        7'b0000011: begin 
		     controls = 13'b1_000_1_0_01_0_00_0_0; // op code - 3    // ALUSrc = 1 because we add register + offset to get memory address
		     load_type_r = funct3;   // funct3 decides LB/LH/LW/LBU/LHU
		  end
		  
		  //I-Type ALU instruction 
		  7'b0010011: controls = 13'b1_000_1_0_00_0_10_0_0; // op code - 19
		  
		  //AUIPC --
		  7'b0010111: controls = 13'b1_100_1_0_00_0_00_0_1; // opcode - 23
		  
		  //Store Type --
        7'b0100011: begin 
		     controls = 13'b0_001_1_1_00_0_00_0_0; // op code - 35 , no register write back but memwrite = 1
		     store_type_r = funct3[1:0];         // 00=SB,01=SH,10=SW 
		  end
		  
		  //R-type ALU
        7'b0110011: controls = 13'b1_xxx_0_0_00_0_10_0_0; // opcode - 51, ALUSrc = 0 and UsePC = 0 since both inputs come from registers
		  
		  //LUI
		  7'b0110111: controls = 13'b1_100_1_0_00_0_00_0_0; // opcode - 55, ALUSrc = 1 to use immediate values 
		  
		  //Branch 
        7'b1100011: controls = 13'b0_010_0_0_00_1_01_0_0; // opcode - 99, ALUop = 01 ie we will subtract for comparision
        
		  //JALR
		  7'b1100111: controls = 13'b1_000_1_0_10_0_00_1_0; // opcode - 103, Jumps to rs1 + immediate and stores return address in rd 
		  
		  //JAL
        7'b1101111: controls = 13'b1_011_0_0_10_0_00_1_0; // opcode - 111, Jumps to PC + immediate, stores PC+4 in rd
		 
        default:   begin controls = 13'b0_000_0_0_00_0_00_0_0; // when op code doesnt match set all control singals to 0 
		  load_type_r = 3'b000;
		  store_type_r = 2'b00;
		  end 
    endcase
end


//unpacking the control signal to designated signals
assign {RegWrite, ImmSrc, ALUSrc, MemWrite, ResultSrc, Branch, ALUOp, Jump, UsePC} = controls;
assign load_type = load_type_r;
assign store_type = store_type_r;

endmodule

