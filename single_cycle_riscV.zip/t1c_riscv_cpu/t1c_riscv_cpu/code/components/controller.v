
// controller.v - controller for RISC-V CPU

module controller (
    input [6:0]  op,   //takes the op code
    input [2:0]  funct3,  //to refine instruction type
    input        funct7b5,   //bit 30 of instruction  (used to distinguish functions that have same funct3)
    input        Zero,   //zero flag ( if ALU result =0 then true) 
	 input        lt, ltu,   //for branch instructions
    output       [1:0] ResultSrc,   // A multiplexer control telling the datapath what value should be written back into the register file
    output       MemWrite,   //Control signal that enables writing to data memory (enable )
    output       PCSrc,    //Selects the next PC source
	 output       ALUSrc,   //selects ALU input source (register vs immediate )
    output       RegWrite,  //enable writing into register files 
	 output        Jump,   //indicate a jump instruction 
    output [2:0] ImmSrc,   //Selects how to interpret immediate bits from the instruction for the immediate generator
    output [3:0] ALUControl,  //Final signal that tells the ALU exactly which operation to perform
	 output [2:0] load_type,  
	 output [1:0] store_type,
	 output UsePC
);
	 
reg PCSrc_; //made for the always block and will be assigned to PCSrc later

wire [1:0] ALUOp; // Guides whether the ALU operation is fixed (ADD, SUB) or should be further decoded
wire       Branch; //Indicates a branch instruction

main_decoder    md (op,funct3, ResultSrc, MemWrite, Branch,
                    ALUSrc, RegWrite, Jump, ImmSrc, ALUOp, load_type, store_type, UsePC);

alu_decoder     ad (op[5], funct3, funct7b5, ALUOp, ALUControl);

// for jump and branch
always @(*) begin
 case (funct3) 

 3'b000 : PCSrc_ = (Branch & Zero) ;   //beq  (branch =1 for only branch instructions ) ALU perform subraction if zero flag high then beq else bne
 3'b001 : PCSrc_ = (Branch & ~Zero) ;   //bne
 3'b100 : PCSrc_ = (Branch & lt) ;  //blt
 3'b101 : PCSrc_ = (Branch & ~lt);   //bge
 3'b110 : PCSrc_ = (Branch & ltu );  //bltu
 3'b111 : PCSrc_ = (Branch & ~ltu); //bgeu
 default PCSrc_ = Jump;             //in other cases jump =0 but for JAL/JALR funct3 is unused hence this logic 
 endcase 
end

assign PCSrc = PCSrc_ ;

endmodule

