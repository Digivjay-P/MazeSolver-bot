onerror {resume}
quietly WaveActivateNextPane {} 0
add wave -noupdate /tb/clk_50M
add wave -noupdate /tb/reset
add wave -noupdate /tb/echo
add wave -noupdate /tb/trig
add wave -noupdate /tb/obstacle
add wave -noupdate /tb/distance_out
add wave -noupdate /tb/exp_trig
add wave -noupdate /tb/exp_distance_out
add wave -noupdate /tb/i
add wave -noupdate /tb/fw
add wave -noupdate /tb/counter
add wave -noupdate /tb/error_count
TreeUpdate [SetDefaultTree]
WaveRestoreCursors {{Cursor 1} {4158150000 ps} 0}
quietly wave cursor active 1
configure wave -namecolwidth 150
configure wave -valuecolwidth 100
configure wave -justifyvalue left
configure wave -signalnamewidth 0
configure wave -snapdistance 10
configure wave -datasetprefix 0
configure wave -rowmargin 4
configure wave -childrowmargin 2
configure wave -gridoffset 0
configure wave -gridperiod 1
configure wave -griddelta 40
configure wave -timeline 0
configure wave -timelineunits ps
update
WaveRestoreZoom {0 ps} {50468617500 ps}
