/*
Module HC_SR04 Ultrasonic Sensor

This module will detect objects present in front of the range, and give the distance in mm.

Input:  clk_50M - 50 MHz clock
        reset   - reset input signal (Use negative reset)
        echo_rx - receive echo from the sensor

Output: trig    - trigger sensor for the sensor
        op     -  output signal to indicate object is present.
        distance_out - distance in mm, if object is present.
*/

// module Declaration
module t1b_ultrasonic(
    input clk_50M, reset, echo_rx,
    output reg trig,
    output op,
    output wire [15:0] distance_out
);
/*
Module HC_SR04 Ultrasonic Sensor

This module will detect objects present in front of the range, and give the distance in mm.

Input:  clk_50M - 50 MHz clock
        reset   - reset input signal (Use negative reset)
        echo_rx - receive echo from the sensor

Output: trig    - trigger sensor for the sensor
        op     -  output signal to indicate object is present.
        distance_out - distance in mm, if object is present.
*/



initial begin
    trig = 0;

end
//////////////////DO NOT MAKE ANY CHANGES ABOVE THIS LINE //////////////////

/*
Add your logic here
*/

localparam SETTLE_CYCLES = 50;        // 1us at 50MHz
localparam TRIG_CYCLES = 550;         // 11us at 50MHz
localparam HOLD_CYCLES = 600552;      // About 12ms at 50MHz
//Defining FSM States 
localparam SETTLE      = 2'd0; // In this state sensor waits for 1us prior to sending a pulse 
localparam PULSE       = 2'd1; // An ultrasonic pulse lasting for 10 us is triggered 
localparam ECHO_MEASURE= 2'd2; // When the sensor receives an echo follwing the pulse, estimation of distance based on the duration of echo signal and speed of sound
localparam HOLD        = 2'd3; // After one measurement the sensor goes to hold for 12ms before repeating the pulse and measurement 


reg [1:0] state;  // Reg to hold previous state
reg [20:0] counter;           // Counter to keep hold of time with increasing clock cycles
reg [20:0] echo_counter;      // Another counter but to measure the duration of time echo stays high
reg [15:0] distance_out_r;    // Given distance_out is a wire defining a reg for sequential assignment inside the clocked always block 


initial begin   // Initializing registers to desired values
state <= SETTLE;
distance_out_r <= 0;
counter <= 0;
echo_counter = 0;
end 

/*always @(posedge clk_50M or negedge reset ) begin
    if (!reset) begin  //In case the sensor is reset the counter must start from zero
        counter       <= 0;
    end else begin
		 if (counter > 600552) begin // once the value of counter goes past the total number of clock cycles elapsed in the FSM counter must reset for next measurement if not it must increment on each posedge of clock
		 counter <= 0;
		end  else begin
		counter <= counter + 1;
		end
		end 
		end */ 
always @(posedge clk_50M or negedge reset  ) begin  //Sequential bloack for state logic and transition
if (!reset) begin // Defining register values after a reset
state <= SETTLE;
counter       <= 0;
distance_out_r <=0;
echo_counter <= 0;
end else begin
		 if (counter > 600552) begin // once the value of counter goes past the total number of clock cycles elapsed in the FSM counter must reset for next measurement if not it must increment on each posedge of clock
		 counter <= 0;
		end  else begin
		counter <= counter + 1;

        case (state)
           SETTLE: begin       //Keeps the trigger low for exactly 50 clock cycles (1us) before tranitioning to PULSE state
			
           
					 if(counter > 50) begin
					 state <= PULSE;
					 trig<= 1;
					 end else begin
					 trig<=0;
					 end
					 
            end
            PULSE: begin     // Sends a pulse of 10us by setting trigger high
              
					 if (counter > 550) begin
					   trig     <= 0;
					 state <= ECHO_MEASURE;
					 end else begin
					   trig     <= 1;
						end
				end
            
            ECHO_MEASURE: begin  //After pulse the sensor waits for the echo signal and on the basis of its duration distance is evaluated
               trig<= 0;
					 if (echo_rx) begin  // echo_counter continues to  increment with each clock cycle until echo_rx is high
					 echo_counter <= echo_counter + 1;
				
					 end else begin
				state <= HOLD;       // After echo_rx goes low distance is evaluated by the prev value of echo_counter
					distance_out_r <= (echo_counter*10)/2945; // To evaluate distance (mm), speed of sound = 340000m/s approx., 1 clk_cycle = 20 ns, time= 20ns*ech0_counter, distance = (speed*time)/2
				
				echo_counter <= 0; //Reset echo_counter 
				end	 
            end
          
            HOLD: begin
          
				
					 if (counter == 0) //After counter resets move back to settle state 
				state <= SETTLE;
					 end 
					 
            
				 default : state <= SETTLE;
           
        endcase
		end
	
    end
end

assign distance_out = distance_out_r;
assign op = (distance_out < 50)? 1'b1:1'b0;  //Op is an output signal that goes high when there is an object thus whenever the sensor receives an echo pulse in return of a trigger, op should go high
//////////////////DO NOT MAKE ANY CHANGES BELOW THIS LINE //////////////////

endmodule
